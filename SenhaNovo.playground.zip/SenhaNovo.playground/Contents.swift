import Foundation

func validateString(_ s: String) -> Bool {
    let firstChar = s[s.startIndex]
    
    // check if first character is uppercase
    if !firstChar.isUppercase {
        return false
    }
    
    var containsLowercase = false
    var containsUppercase = false
    var containsDigit = false
    var digitSequence: [Int] = []
    
    for char in s {
        if char.isLowercase {
            containsLowercase = true
        }
        if char.isUppercase {
            containsUppercase = true
        }
        if char.isNumber {
            containsDigit = true
            let digit = Int(String(char))!
            digitSequence.append(digit)
            if digitSequence.count == 3 && hasConsecutiveNumbers(digitSequence) {
                return false
            }
        } else {
            if !char.isLetter {
                return false
            }
            digitSequence = []
        }
    }
    
    if !containsLowercase || !containsUppercase || !containsDigit {
        return false
    }
    
    if s.count < 5 || s.count > 15 {
        return false
    }
        
    
    return true
}

func hasConsecutiveNumbers(_ nums: [Int]) -> Bool {
    guard nums.count >= 3 else {
        return false
    }
    var count = 1
    for i in 1..<nums.count {
        if nums[i] == nums[i - 1] + 1 {
            count += 1
            if count == 3 {
                return true
            }
        } else {
            count = 1
        }
    }
    return false
}


let pass1 = "Te12!f34kvld"
if validateString(pass1) {
    print("Senha forte")
}else{
    print("Não atende os requisitos!")
}
