import Foundation
func isNotSequence(_ numbers: [Int]) -> Bool {
    if numbers.count>2{
        for i in (0..<numbers.count).reversed(){
            if numbers[i] == numbers[i-1]+1 && numbers[i] == numbers[i-2]+2{
                return false
            }else{
                return true
                
            }
        }
    }
    return true
}

func checkPassword(_ password: String) -> Bool {
    var number: [Int] = []
    var minuscula = 0
    var isNotValide = true
    if password.count > 4 && password.count < 16 {
        for i in password {
            if i.isLetter {
                if i.isLowercase{
                    minuscula += 1
                }
            }else if i.isNumber{
                number.append(Int(String(i))!)
            }else{
                isNotValide = false
            }
        }
        if password[password.startIndex].isUppercase {
            if number != [] && minuscula > 0 && isNotValide && isNotSequence(number){
                return true
            }
            else {
                return false
            }
        }else{
            return false
        }
    }else {
        return false
    }
}


let pass1 = "Teste1223"
if checkPassword(pass1) {
    print("Senha forte")
}else{
    print("Não atende os requisitos!")
}
